import Head from "next/head";
import styles from "../styles/Home.module.css";
import { useState, useEffect } from "react";
import HashLoader from "react-spinners/HashLoader";
// import Navbar from "./navbar";
// import Footer from "./footer";
// import PaymentType from "./paymenttype";
// import Merchant from "./merchants";
// import Favorite from "./Favorite";
// import Purchase from "./purchaseinsight";

import { useRouter } from "next/router";
import { app } from "../firebaseConfig";
import JWT from "expo-jwt";
// import axios from "axios";
import Image from "next/image";
import Tags from "./tags";

import { getAuth, onAuthStateChanged } from "firebase/auth";
// import Receipts from "./receipts";

const defaultEndpoint = "https://rickandmortyapi.com/api/chracter";

export async function getServerSideProps() {
  const res = await fetch(defaultEndpoint);
  const data1 = await res.json();

  return {
    props: {
      data1,
    },
  };
}

export default function Home({ data1 }) {
  console.log(data1);
  const auth = getAuth();
  const router = useRouter();
  const [getUserSesssionId, setUserSessionID] = useState("");
  const [loading, setloading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  const apiKey = "Y7z7tGPZQq2hjD9lmE3BCapcSGxP0HeC6LhOrBVP";

  useEffect(() => {
    var getUserSesssionId = sessionStorage.getItem("UserId");
    setUserSessionID(getUserSesssionId);
  }, []);

  const key = "F29V4kTB3P9Khd935QjJXaCN6Q43KSvX2cU8NKlX";
  const data = {
    userId: "101359060766773967423",
    sub: "com.ihatereceipts.web",
  };

  const myEncodedToken = JWT.encode(data, key, {
    algorithm: "HS256",
  });

  useEffect(() => {
    onAuthStateChanged(auth, (user) => {
      let token = sessionStorage.getItem("Token");
      if (!token) {
        router.push("/");
      }
    });
  }, []);

  useEffect(() => {
    setloading(true);
    setTimeout(() => {
      setloading(false);
    }, 1000);
  }, []);

  return (
    <div>
      <Head>
        <title>I hate Receipt</title>
        <meta name="description" content="I hate receipt" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      {loading ? (
        <div className="loader">
          <HashLoader color={"#F37A24"} loading={loading} size={80} />
        </div>
      ) : (
        <main>
          {/* <Navbar /> */}
          <div className="main">
            <div>
              <h1 className="text-xl font-bold my-4">News and Offers</h1>
            </div>
            <div className="grid grid-cols-2 gap-2 my-4 newsoffer ">
              <div className="grid items-center">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Image
                      alt=""
                      loading="eager"
                      height="228"
                      width="262"
                      src="/images/news.png"
                    />
                  </div>
                  <div className="text-white desc">
                    <h2 className="text-lg font-semibold">
                      News with a long long very long and long title
                    </h2>
                    <p>
                      This is the content of the article, if it gets too long
                      then this is the content of the article, if it gets too
                      long then this is the content of the article, if it gets
                      too long then...
                    </p>
                    <span>Read More</span>
                  </div>
                </div>
              </div>
              <div></div>
            </div>

            <div className="flex justify-center">
              <Tags />
            </div>

            {/* <div className="flex justify-center mt-4">
              <Receipts />
            </div>

            <div className="flex justify-center mt-4">
              <div className="card w-6/12 text-center">
                <PaymentType />
              </div>

              <div className="card w-6/12 text-center">
                <Merchant />
              </div>
            </div>

            <div className="flex justify-center mt-4">
              <Favorite />
              <Purchase />
            </div> */}
          </div>
          {/* <Footer /> */}
        </main>
      )}
    </div>
  );
}
