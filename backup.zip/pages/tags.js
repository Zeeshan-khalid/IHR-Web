import styles from "../styles/Home.module.css";
import Head from "next/head";
import { useState, useEffect } from "react";
import BeatLoader from "react-spinners/BeatLoader";

import { useRouter } from "next/router";
import { app } from "../firebaseConfig";
import JWT from "expo-jwt";

import { getAuth, onAuthStateChanged } from "firebase/auth";

const Tags = () => {
  const router = useRouter();
  const [getUserSesssionId, setUserSessionID] = useState("");
  const [loading, setloading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [toDos, setToDos] = useState();
  const [isLoading, setIsLoading] = useState(false);

  const apiKey = "Y7z7tGPZQq2hjD9lmE3BCapcSGxP0HeC6LhOrBVP";

  useEffect(() => {
    var getUserSesssionId = sessionStorage.getItem("UserId");
    setUserSessionID(getUserSesssionId);
  }, []);

  useEffect(() => {
    const key = "F29V4kTB3P9Khd935QjJXaCN6Q43KSvX2cU8NKlX";
    const data = {
      userId: "101359060766773967423",
      sub: "com.ihatereceipts.web",
    };
    const myEncodedToken = JWT.encode(data, key, {
      algorithm: "HS256",
    });
    var header = {
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        bundleid: "com.ihatereceipts.web",
        Authorization: "Bearer " + myEncodedToken,
      },
    };
    setIsLoading(true);
    fetch("https://api.staging.receiptserver.com/api/v1/tags", header)
      .then((response) => response.json())
      .then((data) => {
        setToDos(data.itemsList); // Set the toDo variable
        setIsLoading(false);
      });
  }, []);

  useEffect(() => {
    const auth = getAuth();
    onAuthStateChanged(auth, (user) => {
      let token = sessionStorage.getItem("Token");
      if (!token) {
        router.push("/");
      }
    });
  }, []);

  if (isLoading) {
    return (
      <div className="miniloader">
        <BeatLoader color={"#F37A24"} loading={isLoading} size={15} />
      </div>
    );
  }
  if (!toDos) {
    return <h1>No List to show</h1>;
  }
  return (
    <div className="card w-12/12 bg-base-100 border w-full mtl">
      <div className="card-body">
        <h1 className="card-title justify-between">
          <div>
            <span className="">Tags</span>
            <span
              className="tooltip tooltip-right align-super text-sm"
              data-tip="Select a tag to search for those receipts."
            >
              &#9432;
            </span>
          </div>
          <div className="card-actions">
            <label htmlFor="tags-modal" className="modal-button text-sm">
              View All
            </label>
          </div>
        </h1>

        <input type="checkbox" id="tags-modal" className="modal-toggle" />

        <label htmlFor="tags-modal" className="modal cursor-pointer">
          <label
            className="modal-box relative h-full w-11/12 max-w-7xl"
            htmlFor=""
          >
            <label
              htmlFor="tags-modal"
              className="modal-button btn btn-circle btn-sm absolute right-2 top-2"
            >
              ✕
            </label>

            <h1 className="text-2xl font-bold">
              Tags
              <span
                className="tooltip tooltip-right align-super text-sm"
                data-tip="Select a tag to search for those receipts."
              >
                &#9432;
              </span>
            </h1>
            <div className="relative my-4 w-full">
              <span className="absolute z-10 h-full w-8 items-center justify-center rounded py-3 pl-3 text-center text-slate-300">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
              </span>
              <input
                type="text"
                placeholder="Search..."
                onChange={(event) => {
                  setSearchTerm(event.target.value);
                }}
                className="relative w-full rounded border bg-white px-3 py-3 pl-10 text-lg placeholder-slate-300 outline-none focus:outline-none focus:ring"
              />
            </div>

            <div className="overflow-x-auto text-left">
              <table className="table w-full table-fixed">
                <thead>
                  <tr>
                    <th className="w-1/12">Favorite</th>
                    <th className="w-2/12">Name</th>
                    <th className="">Category</th>
                    <th className="w-2/12 text-center">
                      Items
                      <span className="bold brightness-150">&uarr;</span>
                    </th>
                    <th className="w-2/12 text-center">
                      Last Used
                      <span className="bold brightness-150">&darr;</span>
                    </th>
                    <th className="w-2/12 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {toDos
                    .filter((tags) => {
                      if (searchTerm == "") {
                        return tags;
                      } else if (
                        tags
                          .toLocaleLowerCase()
                          .includes(searchTerm.toLocaleLowerCase())
                      ) {
                        return tags;
                      }
                    })
                    .map(function (toDo, id) {
                      return (
                        <tr key={id}>
                          <td className="text-center">
                            <label>
                              <input type="checkbox" className="checkbox" />
                            </label>
                          </td>
                          <td>
                            <span className="badge badge-outline badge-lg">
                              #{toDo}
                            </span>
                          </td>
                          <td>category for tagname</td>
                          <td className="text-center font-mono">nn</td>
                          <td className="text-center font-mono">mm-dd-yyyy</td>
                          <td className="flex justify-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="h-6 w-6 text-red-500"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                              strokeWidth="2"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                              />
                            </svg>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </label>
        </label>
        <div className="truncate">
          right here
          {/* {data.map((curElem) => {
            return (
              <div key={curElem.id}>
                <h3>{curElem.id}</h3>
                <h3>{curElem.title}</h3>
              </div>
            );
          })} */}
          {toDos.map(function (toDo, id) {
            return (
              <div className="badge badge-outline badge-lg mr-2" key={id}>
                #{toDo}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
export default Tags;
