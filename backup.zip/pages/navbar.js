import { useRouter } from "next/router";
import Profile from "./profile";
import Image from "next/image";

const Navbar = () => {
  const router = useRouter();

  const signOut = () => {
    let token = sessionStorage.clear();
    if (!token) {
      router.push("/");
    }
  };
  return (
    <div>
      <nav>
        <div className="navbar bg-base-100">
          <div className="flex-1 dropdown ml-[30rem]">
            <label tabIndex="0" className="btn">
              <Image
                alt=""
                loading="eager"
                height="50"
                width="100%"
                src="/images/logo.png"
              />
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 text-[#4B4B4B]"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={2}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M19 9l-7 7-7-7"
                />
              </svg>
            </label>
            <div
              tabIndex="0"
              className="mt-3 card card-compact dropdown-content w-80 bg-base-100 shadow right-64"
            >
              <div className="card-body">
                <div className="mb-3">
                  <p className="font-bold text-lg text-xl ml-2">Services</p>
                </div>
                <div className="flex items-center notify pb-4">
                  <div className="ml-2">
                    <label
                      htmlFor="tags-modal"
                      className="modal-button text-sm"
                    >
                      <p className="text-sm font-semibold">Tags</p>
                    </label>
                  </div>
                </div>
                <div className="flex items-center notify pb-4">
                  <div className="ml-2">
                    <label htmlFor="receipt" className="modal-button text-sm">
                      <p className="text-sm font-semibold">Receipts</p>
                    </label>
                  </div>
                </div>
                <div className="flex items-center notify pb-4">
                  <div className="ml-2">
                    <label htmlFor="favorites" className="modal-button text-sm">
                      <p className="text-sm font-semibold">Favorites</p>
                    </label>
                  </div>
                </div>
                <div className="flex items-center notify pb-4">
                  <div className="ml-2">
                    <label htmlFor="payment" className="modal-button text-sm">
                      <p className="text-sm font-semibold">Payment Types</p>
                    </label>
                  </div>
                </div>
                <div className="flex items-center notify pb-4">
                  <div className="ml-2">
                    <label htmlFor="merchant" className="modal-button text-sm">
                      <p className="text-sm font-semibold">Top Merchants</p>
                    </label>
                  </div>
                </div>
                <div className="flex items-center notify pb-4">
                  <div className="ml-2">
                    <p className="text-sm font-semibold">Purchase Insights</p>
                  </div>
                </div>
                <div className="flex items-center notify pb-4">
                  <div className="ml-2">
                    <a href="./profile">
                      <p className="text-sm font-semibold">Account Info</p>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="flex-none gap-2">
            <div className="card-actions">
              <label
                htmlFor="uploads"
                className="modal-button btn bg-[#ea3358]"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 mr-3"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={2}
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>{" "}
                Add a Receipt
              </label>
            </div>

            <input type="checkbox" id="uploads" className="modal-toggle" />

            <label htmlFor="uploads" className="modal cursor-pointer">
              <label
                className="modal-box relative h-full w-11/12 max-w-7xl"
                htmlFor=""
              >
                <div className="customborder  flex items-center justify-center">
                  <form className=" space-x-6">
                    <div className="shrink-0 flex items-center justify-center mb-5">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-20 w-20 text-[#ea3358]"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                        />
                      </svg>
                    </div>
                    <label className="block text-center flex justify-center">
                      <input
                        type="file"
                        className="block w-full text-sm text-slate-500
                      file:mr-4 file:py-2 file:px-4
                      file:rounded-full file:border-0
                      file:text-sm file:font-semibold
                      file:bg-violet-50 file:text-violet-700
                      hover:file:bg-violet-100
                    "
                      />
                      <span className="sr-only text-sm text-[#808080] relative">
                        (Up to 10)
                      </span>
                    </label>
                  </form>
                </div>
              </label>
            </label>

            <div className="form-control">
              <input
                type="text"
                placeholder="Search"
                className="input input-bordered"
              />
            </div>
            <div className="dropdown dropdown-end">
              <label tabIndex="0" className="btn btn-ghost btn-circle">
                <div className="indicator">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
                    />
                  </svg>
                  <span className="badge badge-sm indicator-item bg-[#ea3358]">
                    5
                  </span>
                </div>
              </label>
              <div
                tabIndex="0"
                className="mt-3 card card-compact dropdown-content w-80 bg-base-100 shadow "
              >
                <div className="card-body">
                  <div className="flex">
                    <p className="font-bold text-lg text-xl">Notifications</p>
                    <a href="">
                      <p className="text-right text-[#ea3358]">View all</p>
                    </a>
                  </div>
                  <div className="flex items-center notify pb-4">
                    <div className="-space-x-5 avatar-group">
                      <div className="avatar">
                        <div className="w-10 h-10">
                          <Image
                            alt=""
                            loading="eager"
                            width="60"
                            height="50"
                            src="/images/profile-sm.png"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="ml-3">
                      <p className="text-md font-bold">
                        Notification Example Title
                      </p>
                      <p className="Truncate">Lorem ipsum dolor sit....</p>
                    </div>
                    <div className="ml-8 text-right">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </div>
                  </div>
                  <div className="flex items-center notify pb-4">
                    <div className="-space-x-5 avatar-group">
                      <div className="avatar">
                        <div className="w-10 h-10">
                          <Image
                            alt=""
                            loading="eager"
                            width="60"
                            height="50"
                            src="/images/profile-sm.png"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="ml-3">
                      <p className="text-md font-bold">
                        Notification Example Title
                      </p>
                      <p className="Truncate">Lorem ipsum dolor sit....</p>
                    </div>
                    <div className="ml-8">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </div>
                  </div>
                  <div className="flex items-center notify pb-4">
                    <div className="-space-x-5 avatar-group">
                      <div className="avatar">
                        <div className="w-10 h-10">
                          <Image
                            alt=""
                            loading="eager"
                            width="60"
                            height="50"
                            src="/images/profile-sm.png"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="ml-3">
                      <p className="text-md font-bold">
                        Notification Example Title
                      </p>
                      <p className="Truncate">Lorem ipsum dolor sit....</p>
                    </div>
                    <div className="ml-8">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </div>
                  </div>
                  <div className="flex items-center notify pb-4">
                    <div className="-space-x-5 avatar-group">
                      <div className="avatar">
                        <div className="w-10 h-10">
                          <Image
                            alt=""
                            loading="eager"
                            width="60"
                            height="50"
                            src="/images/profile-sm.png"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="ml-3">
                      <p className="text-md font-bold">
                        Notification Example Title
                      </p>
                      <p className="Truncate">Lorem ipsum dolor sit....</p>
                    </div>
                    <div className="ml-8">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </div>
                  </div>
                  <div className="flex items-center notify pb-4">
                    <div className="-space-x-5 avatar-group">
                      <div className="avatar">
                        <div className="w-10 h-10">
                          <Image
                            alt=""
                            loading="eager"
                            width="60"
                            height="50"
                            src="/images/profile-sm.png"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="ml-3">
                      <p className="text-md font-bold">
                        Notification Example Title
                      </p>
                      <p className="Truncate">Lorem ipsum dolor sit....</p>
                    </div>
                    <div className="ml-8">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="dropdown dropdown-end">
              <label tabIndex="0" className="btn btn-ghost btn-circle avatar">
                <div className="w-10 rounded-full">
                  <Image
                    alt=""
                    loading="eager"
                    width="60"
                    height="50"
                    src="/images/profile-sm.png"
                  />
                </div>
              </label>
              <div
                tabIndex="0"
                className="mt-3 card card-compact dropdown-content w-80 bg-base-100 shadow"
              >
                <div className="card-body">
                  <div className="mb-3">
                    <p className="font-bold text-lg text-xl">My IHR</p>
                  </div>
                  <div className="flex items-center notify pb-4">
                    <div className="-space-x-5 avatar-group">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                      </svg>
                    </div>
                    <div className="ml-2">
                      <a href="./profile">
                        <p className="text-sm font-semibold">Account Info</p>
                      </a>
                    </div>
                  </div>
                  <div className="flex items-center notify pb-4">
                    <div className="-space-x-5 avatar-group">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                      </svg>
                    </div>
                    <div className="ml-2">
                      <p className="text-sm font-semibold">Deleted Receipts</p>
                    </div>
                  </div>
                  <div className="mt-2 mb-4">
                    <p className="font-bold text-lg text-xl">Support</p>
                  </div>
                  <div className="flex items-center notify pb-4">
                    <div className="-space-x-5 avatar-group">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                      </svg>
                    </div>
                    <div className="ml-2">
                      <p className="text-sm">Guide to IHR</p>
                    </div>
                  </div>
                  <div className="flex items-center notify pb-4">
                    <div className="-space-x-5 avatar-group">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                      </svg>
                    </div>
                    <div className="ml-2">
                      <p className="text-sm">FAQS</p>
                    </div>
                  </div>
                  <div className="flex items-center notify pb-4">
                    <div className="-space-x-5 avatar-group">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                      </svg>
                    </div>
                    <div className="ml-2">
                      <p className="text-sm">Terms of Services</p>
                    </div>
                  </div>
                  <div className="flex items-center notify pb-4">
                    <div className="-space-x-5 avatar-group">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                      </svg>
                    </div>
                    <div className="ml-2">
                      <p className="text-sm">Privacy Policy</p>
                    </div>
                  </div>
                  <div className="flex items-center notify pb-4">
                    <div className="-space-x-5 avatar-group">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                      </svg>
                    </div>
                    <div className="ml-2">
                      <p className="text-sm">Send Feedback</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between notify pb-4">
                    <div className="ml-3">
                      <p className="text-xl font-bold">John Smith</p>
                      <p className="text-[grey] text-xs">john@gmail.com</p>
                    </div>
                    <div className="ml-8 text-right">
                      <button onClick={signOut}>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="text-[#ea3358] h-6 w-6"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                          strokeWidth={2}
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
                          />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
};
export default Navbar;
